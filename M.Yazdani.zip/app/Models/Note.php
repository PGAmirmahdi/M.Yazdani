<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Note extends Model
{
    use HasFactory;

    protected $guarded = [];

    const STATUS = [
        'done' => 'انجام شده',
        'undone' => 'انجام نشده',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
